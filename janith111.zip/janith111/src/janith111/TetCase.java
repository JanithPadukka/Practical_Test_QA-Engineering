package janith111;

import java.sql.Driver;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.*;
import java.util.Random;
import java.util.UUID;


public class TetCase {

static WebDriver driver;
	

		


	@Test
	public static void driveropen() {
		System.out.println("tghth");
		// initiate driver

		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "//driver_automationpractice//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		// open browser
		driver.get("http://automationpractice.com/index.php");
		driver.manage().window().maximize();

		driver.findElement(By.xpath("//a[@title='Log in to your customer account']")).click();
		// explicit wait
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='email_create']")));
		// type
		String rand = UUID.randomUUID().toString();
		driver.findElement(By.xpath("//input[@id='email_create']")).sendKeys(rand+"@dsfdf.dedfv");
		driver.findElement(By.xpath("//span[normalize-space()='Create an account']")).click();
		// implicit wait
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@id='id_gender1']")).click();

		driver.findElement(By.xpath(
				"//label[contains(text(),'First name')]/./following-sibling::input[@name=\"customer_firstname\"]"))
				.sendKeys("advadvsdv fgrgr");

		driver.findElement(By.xpath("//input[@name='customer_lastname']")).sendKeys("dfdeefef");

		driver.findElement(By.xpath("//input[@type='password']")).sendKeys("dfdeefef");
		// select
		Select days = new Select(driver.findElement(By.xpath("//select[@id='days']")));
		// Select the option with value "6"
		days.selectByValue("6");
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
	
		// select
		Select months = new Select(driver.findElement(By.xpath("//select[@id='months']")));
		// Select the option with January
		months.selectByIndex(5);
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		
		Select years = new Select(driver.findElement(By.xpath("//select[@id='years']")));
		// Select the option with January
		years.selectByValue("1996");
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//input[@name='firstname']")).sendKeys("dfdeefef");
		driver.findElement(By.xpath("//input[@name='lastname']")).sendKeys("dfdeefef");
		driver.findElement(By.xpath("//input[@name='address1']")).sendKeys("dfdeefef");
		driver.findElement(By.xpath("//input[@name='city']")).sendKeys("dfdeefef");
		
		Select id_state = new Select(driver.findElement(By.xpath("//select[@id='id_state']")));
		// Select the option with January
		id_state.selectByVisibleText("Alabama");
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@name='postcode']")).sendKeys("00000");
		driver.findElement(By.xpath("//input[@name='phone_mobile']")).sendKeys("01615416516516000");
		
		driver.findElement(By.xpath("//span[text()='Register']")).click();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[text()='Dresses'])[2]")));
		driver.findElement(By.xpath("(//a[text()='Dresses'])[2]")).click();
		
		//click("(//a[@title='Printed Dress'])[2]");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[@title='Printed Dress'])[2]")));
		
		Actions actions = new Actions(driver);
		WebElement Dress = driver.findElement(By.xpath("(//a[@title='Printed Dress'])[2]"));
		//Dress.click();
		actions.moveToElement(Dress).build().perform();
		driver.findElement(By.xpath("(//span[text()='Add to cart'])[1]")).click();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[@title='Continue shopping'])[1]")));
		driver.findElement(By.xpath("(//span[@title='Continue shopping'])[1]")).click();
		
		WebElement tshirt = driver.findElement(By.xpath("(//a[@title=\"T-shirts\"])[2]"));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[text()='Dresses'])[2]")));
		tshirt.click();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//a[@title='Faded Short Sleeve T-shirts'])[2]")));
		
		
		WebElement Sleeve = driver.findElement(By.xpath("(//a[@title='Faded Short Sleeve T-shirts'])[2]"));
		actions.moveToElement(Sleeve).build().perform();
		driver.findElement(By.xpath("(//span[text()='Add to cart'])[1]")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("(//a[@title='Proceed to checkout'])[1]")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//i[@class='icon-plus'])[1]")));
		driver.findElement(By.xpath("(//i[@class='icon-plus'])[1]")).click();
		WebElement total = driver.findElement(By.xpath("//span[@id=\"total_price\"]"));
		String subtotal =  total.getText();
		String expecterdvalue = "$73.33";
		if (subtotal.equals(expecterdvalue)) {
			Reporter.log(subtotal+" corect");
		}
		else {
			Reporter.log(subtotal+" wrong");
			//fail(expecterdvalue+"not matched with "+subtotal);
		}
		
		
				WebElement countss = driver.findElement(By.xpath("(//span[@class=\"ajax_cart_quantity\"])[1]"));
				
				String counts =  countss.getText();
				String expecterdvaluecounts = "3";
				if (counts.equals(expecterdvaluecounts)) {
					Reporter.log(counts+" corect");
				}
				else {
					Reporter.log(counts+" wrong");
					//fail(counts+"not matched with "+expecterdvaluecounts);
				}
				
				//WebElement checkout = driver.findElement(By.xpath("(//span[text()='Proceed to checkout'])[1]"));
				
				WebElement checkout = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[text()='Proceed to checkout'])[1]")));
				checkout.click();
				WebElement checkout2 = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[text()='Proceed to checkout'])[1]")));
				checkout2.click();
				
				
				driver.findElement(By.xpath("//input[@type=\"checkbox\"]")).click();
				WebElement checkout3 = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@name=\"processCarrier\"]")));
				checkout3.click();
				driver.findElement(By.xpath("//a[@class=\"bankwire\"]")).click();
				
				driver.findElement(By.xpath("//span[text()='I confirm my order']")).click();
				driver.close();
		

	}


	
	
}
